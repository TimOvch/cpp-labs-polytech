//
//  Debug.h
//  sem2lab2
//
//  Created by Тимофей Овчинников on 06.02.2024.
//

#ifndef Debug_h
#define Debug_h

//#define DebugVersion

#endif /* Debug_h */
