//
//  main.hpp
//  sem2lab4
//
//  Created by Тимофей Овчинников on 07.03.2024.
//

#ifndef main_hpp
#define main_hpp
#include "List.hpp"
#include <stdio.h>
#include <fstream>
#include <iostream>
#endif /* main_hpp */
